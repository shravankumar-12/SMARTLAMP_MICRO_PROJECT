import RPi.GPIO as GPIO
from time import sleep

# Define GPIO pins
ldr_pin = 27  # GPIO pin connected to the LDR
relay_pin = 17  # GPIO pin connected to the transistor base (via a resistor)

# Setup GPIO
GPIO.setwarnings(False)  # Disable warnings (optional)
GPIO.setmode(GPIO.BCM)
GPIO.setup(relay_pin, GPIO.OUT)
GPIO.setup(ldr_pin, GPIO.IN)  # LDR pin as input

def read_ldr():
    ldr_value = GPIO.input(ldr_pin)
    return ldr_value

try:
    while True:
        ldr_value = read_ldr()
        
        if ldr_value == GPIO.LOW:
            # It's dark, activate the relay (turn on the light)
            GPIO.output(relay_pin, GPIO.LOW)
            print("Light is ON")
        else:
            # It's bright, deactivate the relay (turn off the light)
            GPIO.output(relay_pin, GPIO.HIGH)
            print("Light is OFF")
        
        sleep(1)  # Adjust delay as needed for your application

except KeyboardInterrupt:
    GPIO.cleanup()
